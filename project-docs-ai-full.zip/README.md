ProjectDocsAI — Render-ready fullstack (expanded)
================================================

Contents:
- backend/        (Express API, PostgreSQL via DATABASE_URL, JWT auth, OpenAI integration)
- frontend/       (Vite + React UI for auth, projects, uploads, search, analytics)
- render.yaml     (Render service config)
- package.json    (root scripts: build + start)

Quick deploy to Render:
1. Create Git repo and push this project to it.
2. In Render, create a new Web Service and connect the repo.
3. Set environment variables in Render: OPENAI_API_KEY and DATABASE_URL (Render can provision a Postgres DB and provide DATABASE_URL).
4. Render will run `npm run build` then `npm start` (see render.yaml).

Local dev:
1. npm install
2. Create a .env with OPENAI_API_KEY and DATABASE_URL (or run a local Postgres)
3. cd frontend && npm install && npm run dev
4. node backend/server.js

Notes:
- Uploaded files are not stored in DB; we extract text and store metadata and text in Postgres.
- For production, consider S3 for file storage and a proper migrations setup.
