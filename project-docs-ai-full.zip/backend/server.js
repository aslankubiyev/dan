import express from 'express'
import multer from 'multer'
import path from 'path'
import fs from 'fs'
import cors from 'cors'
import pdf from 'pdf-parse'
import mammoth from 'mammoth'
import OpenAI from 'openai'
import knexLib from 'knex'
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const app = express()
app.use(cors())
app.use(express.json())

const OPENAI_KEY = process.env.OPENAI_API_KEY
const openai = OPENAI_KEY ? new OpenAI({ apiKey: OPENAI_KEY }) : null

// Database (Postgres) via DATABASE_URL env var
const DATABASE_URL = process.env.DATABASE_URL || null
let knex = null
if (DATABASE_URL) {
  knex = knexLib({
    client: 'pg',
    connection: DATABASE_URL,
    pool: { min: 0, max: 7 }
  })
} else {
  // fallback to sqlite file for local dev (simple)
  knex = knexLib({
    client: 'sqlite3',
    connection: { filename: path.join(__dirname, '../dev.sqlite') },
    useNullAsDefault: true
  })
}

// Ensure tables exist (simple migration)
async function ensureTables() {
  if (!(await knex.schema.hasTable('users'))) {
    await knex.schema.createTable('users', (t) => {
      t.increments('id').primary()
      t.string('email').unique().notNullable()
      t.string('password_hash').notNullable()
      t.timestamps(true, true)
    })
  }
  if (!(await knex.schema.hasTable('projects'))) {
    await knex.schema.createTable('projects', (t) => {
      t.increments('id').primary()
      t.string('name').notNullable()
      t.integer('owner_id').references('id').inTable('users')
      t.timestamps(true, true)
    })
  }
  if (!(await knex.schema.hasTable('documents'))) {
    await knex.schema.createTable('documents', (t) => {
      t.increments('id').primary()
      t.string('filename').notNullable()
      t.text('text')
      t.text('summary')
      t.text('tags') // JSON array string
      t.integer('project_id').references('id').inTable('projects')
      t.timestamps(true, true)
    })
  }
}
ensureTables().catch(console.error)

// Multer temp storage
const uploadRoot = path.join(__dirname, '..', 'uploads')
if (!fs.existsSync(uploadRoot)) fs.mkdirSync(uploadRoot, { recursive: true })

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = uploadRoot
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
    cb(null, dir)
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname)
  }
})
const upload = multer({ storage })

// Auth helpers
const JWT_SECRET = process.env.JWT_SECRET || 'replace_this_in_prod'

async function hashPassword(p) { return await bcrypt.hash(p, 10) }
async function verifyPassword(p, hash) { return await bcrypt.compare(p, hash) }

function authMiddleware(req, res, next) {
  const auth = req.headers.authorization
  if (!auth) return res.status(401).json({ error: 'missing auth' })
  const token = auth.replace('Bearer ', '')
  try {
    const data = jwt.verify(token, JWT_SECRET)
    req.user = data
    next()
  } catch (e) {
    return res.status(401).json({ error: 'invalid token' })
  }
}

// extract text
async function extractText(filePath, originalName) {
  const lower = originalName.toLowerCase()
  try {
    if (lower.endsWith('.pdf')) {
      const data = await pdf(fs.readFileSync(filePath))
      return data.text || ''
    } else if (lower.endsWith('.docx')) {
      const res = await mammoth.extractRawText({ path: filePath })
      return res.value || ''
    } else {
      return fs.readFileSync(filePath, 'utf8')
    }
  } catch (e) {
    console.error('extractText error', e)
    return ''
  }
}

async function aiSummarize(text) {
  if (!openai) return { summary: text.slice(0,400)+(text.length>400?'...':''), tags: [] }
  try {
    const prompt = `Extract up to 8 short tags (comma separated) and a 2-3 sentence summary for the following document:\n\n${text.slice(0,4000)}`
    const resp = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 300
    })
    const out = resp.choices?.[0]?.message?.content || ''
    const tagsMatch = out.match(/TAGS?:\s*(.*)/i)
    const summaryMatch = out.match(/SUMMARY?:\s*([\s\S]*)/i)
    const tags = tagsMatch ? tagsMatch[1].split(',').map(s=>s.trim()).filter(Boolean) : []
    const summary = summaryMatch ? summaryMatch[1].trim() : out.slice(0,400)
    return { summary, tags }
  } catch (e) {
    console.error('AI error', e)
    return { summary: text.slice(0,400), tags: [] }
  }
}

// Routes
app.get('/api/health', (req,res)=>res.json({status:'ok'}))

// Auth
app.post('/api/auth/register', async (req,res)=>{
  const { email, password } = req.body
  if (!email || !password) return res.status(400).json({ error: 'missing' })
  const hash = await hashPassword(password)
  const [id] = await knex('users').insert({ email, password_hash: hash }).returning('id')
  const token = jwt.sign({ id }, JWT_SECRET)
  res.json({ token })
})

app.post('/api/auth/login', async (req,res)=>{
  const { email, password } = req.body
  const user = await knex('users').where({ email }).first()
  if (!user) return res.status(400).json({ error: 'invalid' })
  const ok = await verifyPassword(password, user.password_hash)
  if (!ok) return res.status(400).json({ error: 'invalid' })
  const token = jwt.sign({ id: user.id }, JWT_SECRET)
  res.json({ token })
})

// Projects
app.post('/api/projects', authMiddleware, async (req,res)=>{
  const { name } = req.body
  const [id] = await knex('projects').insert({ name, owner_id: req.user.id }).returning('id')
  res.json({ id, name })
})

app.get('/api/projects', authMiddleware, async (req,res)=>{
  const rows = await knex('projects').where({ owner_id: req.user.id }).orderBy('created_at','desc')
  res.json(rows)
})

// Upload document
app.post('/api/projects/:id/upload', authMiddleware, upload.single('file'), async (req,res)=>{
  if (!req.file) return res.status(400).json({ error: 'no file' })
  const proj = await knex('projects').where({ id: req.params.id, owner_id: req.user.id }).first()
  if (!proj) return res.status(404).json({ error: 'project not found' })
  const text = await extractText(req.file.path, req.file.originalname)
  const ai = await aiSummarize(text)
  const tagsJson = JSON.stringify(ai.tags)
  const [docId] = await knex('documents').insert({
    filename: req.file.originalname,
    text,
    summary: ai.summary,
    tags: tagsJson,
    project_id: proj.id
  }).returning('id')
  res.json({ id: docId, filename: req.file.originalname, summary: ai.summary, tags: ai.tags })
})

// List docs + search
app.get('/api/projects/:id/docs', authMiddleware, async (req,res)=>{
  const proj = await knex('projects').where({ id: req.params.id, owner_id: req.user.id }).first()
  if (!proj) return res.status(404).json({ error: 'project not found' })
  const docs = await knex('documents').where({ project_id: proj.id }).orderBy('created_at','desc')
  res.json(docs.map(d=>({ id: d.id, filename: d.filename, summary: d.summary, tags: JSON.parse(d.tags || '[]') })))
})

app.get('/api/projects/:id/search', authMiddleware, async (req,res)=>{
  const q = (req.query.q || '').toLowerCase()
  const proj = await knex('projects').where({ id: req.params.id, owner_id: req.user.id }).first()
  if (!proj) return res.status(404).json({ error: 'project not found' })
  const docs = await knex('documents').where({ project_id: proj.id }).andWhere(function(){
    this.whereRaw("lower(filename) like ?", ['%'+q+'%']).orWhereRaw("lower(summary) like ?", ['%'+q+'%']).orWhereRaw("lower(text) like ?", ['%'+q+'%'])
  }).orderBy('created_at','desc')
  res.json(docs.map(d=>({ id: d.id, filename: d.filename, summary: d.summary, tags: JSON.parse(d.tags || '[]') })))
})

// Analytics: counts and top tags
app.get('/api/projects/:id/analytics', authMiddleware, async (req,res)=>{
  const proj = await knex('projects').where({ id: req.params.id, owner_id: req.user.id }).first()
  if (!proj) return res.status(404).json({ error: 'project not found' })
  const count = await knex('documents').where({ project_id: proj.id }).count('* as c').first()
  const rows = await knex('documents').where({ project_id: proj.id }).select('tags')
  const tagCounts = {}
  for (const r of rows) {
    const tags = JSON.parse(r.tags || '[]')
    for (const t of tags) tagCounts[t] = (tagCounts[t]||0)+1
  }
  res.json({ count: count.c, topTags: Object.entries(tagCounts).sort((a,b)=>b[1]-a[1]).slice(0,10) })
})

const PORT = process.env.PORT || 4000
app.listen(PORT, ()=>console.log('Server running on', PORT))
export default app
