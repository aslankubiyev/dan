import React, { useEffect, useState } from 'react'

function App(){
  const [token, setToken] = useState(localStorage.getItem('token')||'')
  const [projects, setProjects] = useState([])
  const [selected, setSelected] = useState(null)
  useEffect(()=>{
    if(token) fetch('/api/projects',{headers:{Authorization:'Bearer '+token}}).then(r=>r.json()).then(setProjects)
  },[token])
  if(!token) return <Auth onAuth={(t)=>{localStorage.setItem('token',t); setToken(t)}} />
  return (
    <div style={{padding:20}}>
      <h1>ProjectDocs AI</h1>
      <div style={{display:'flex',gap:20}}>
        <div style={{width:260}}>
          <h3>Projects</h3>
          <ul>
            {projects.map(p=><li key={p.id}><button onClick={()=>setSelected(p.id)}>{p.name}</button></li>)}
          </ul>
          <button onClick={async ()=>{ const name=prompt('Project name'); if(!name) return; const res=await fetch('/api/projects',{method:'POST',headers:{'Content-Type':'application/json', Authorization:'Bearer '+token}, body:JSON.stringify({name})}); const data=await res.json(); setProjects([data,...projects])}}>New Project</button>
          <button onClick={()=>{localStorage.removeItem('token'); setToken('')}} style={{marginTop:10}}>Logout</button>
        </div>
        <div style={{flex:1}}>{selected? <ProjectView projectId={selected} token={token}/> : <div>Select project</div>}</div>
      </div>
    </div>
  )
}

function Auth({onAuth}){
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const register=async ()=>{
    const res=await fetch('/api/auth/register',{method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email,password})})
    const data=await res.json(); if(data.token) onAuth(data.token)
  }
  const login=async ()=>{
    const res=await fetch('/api/auth/login',{method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email,password})})
    const data=await res.json(); if(data.token) onAuth(data.token)
  }
  return (<div style={{padding:20}}>
    <h2>Login / Register</h2>
    <input placeholder='email' value={email} onChange={e=>setEmail(e.target.value)} /><br/>
    <input placeholder='password' type='password' value={password} onChange={e=>setPassword(e.target.value)} /><br/>
    <button onClick={login}>Login</button>
    <button onClick={register}>Register</button>
  </div>)
}

function ProjectView({projectId, token}){
  const [docs,setDocs]=useState([])
  const [file,setFile]=useState(null)
  const [q,setQ]=useState('')
  const [searchRes,setSearchRes]=useState([])
  useEffect(()=>{ fetch(`/api/projects/${projectId}/docs`, {headers:{Authorization:'Bearer '+token}}).then(r=>r.json()).then(setDocs) },[projectId, token])
  const upload=async ()=>{
    if(!file) return alert('choose file')
    const fd=new FormData(); fd.append('file', file)
    const res=await fetch(`/api/projects/${projectId}/upload`, {method:'POST', headers:{Authorization:'Bearer '+token}, body:fd})
    const data=await res.json()
    fetch(`/api/projects/${projectId}/docs`,{headers:{Authorization:'Bearer '+token}}).then(r=>r.json()).then(setDocs)
  }
  const search=async ()=>{
    const res=await fetch(`/api/projects/${projectId}/search?q=${encodeURIComponent(q)}`, {headers:{Authorization:'Bearer '+token}})
    const data=await res.json()
    setSearchRes(data)
  }
  return (<div>
    <h2>Project {projectId}</h2>
    <div><input type="file" onChange={e=>setFile(e.target.files?.[0]||null)} /><button onClick={upload}>Upload</button></div>
    <h4>Docs</h4><ul>{docs.map(d=><li key={d.id}>{d.filename} <div style={{color:'#555'}}>{d.summary}</div></li>)}</ul>
    <h4>Search</h4><input value={q} onChange={e=>setQ(e.target.value)} /><button onClick={search}>Search</button>
    <ul>{searchRes.map(r=><li key={r.id}><b>{r.filename}</b> — {r.summary}</li>)}</ul>
  </div>)
}

export default App
