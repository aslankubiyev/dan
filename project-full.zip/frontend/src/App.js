import React from "react";

function App() {
  return (
    <div style={{textAlign: "center", marginTop: "50px"}}>
      <h1>Hello from React!</h1>
      <p>Backend API is available at /api/hello</p>
    </div>
  );
}

export default App;